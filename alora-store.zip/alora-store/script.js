/* ============================================================
   ALORA — store logic
   Replace PRODUCTS below with your real items (and swap the
   placeholder SVGs in product-media for real photos — see README).
   ============================================================ */

const PRODUCTS = [
  { id: "d1", name: "Terracotta Wrap Dress",   category: "Dresses", price: 2499, shape: "dress",  tint: "maroon" },
  { id: "d2", name: "Sage Midi Slip",          category: "Dresses", price: 2299, shape: "dress",  tint: "sage" },
  { id: "d3", name: "Undyed Cotton Sundress",  category: "Dresses", price: 2799, shape: "dress",  tint: "cream" },
  { id: "t1", name: "Clay Linen Shirt",        category: "Tops",    price: 1499, shape: "top",    tint: "maroon" },
  { id: "t2", name: "Sage Boxy Tee",           category: "Tops",    price: 999,  shape: "top",    tint: "sage" },
  { id: "t3", name: "Raw Cotton Blouse",       category: "Tops",    price: 1699, shape: "top",    tint: "cream" },
  { id: "b1", name: "Maroon Wide-Leg Trouser", category: "Bottoms", price: 1899, shape: "bottom", tint: "maroon" },
  { id: "b2", name: "Sage Linen Trouser",      category: "Bottoms", price: 1899, shape: "bottom", tint: "sage" },
  { id: "b3", name: "Undyed Straight Pant",    category: "Bottoms", price: 1799, shape: "bottom", tint: "cream" },
];

/* ---------- Garment placeholder art ---------- */
function garmentSVG(shape, tint) {
  const color = tint === "maroon" ? "var(--maroon)" : tint === "sage" ? "var(--sage-dark)" : "var(--ink-soft)";
  const shapes = {
    dress: `<path d="M35 10 L30 22 L20 90 L80 90 L70 22 L65 10 Q50 20 35 10 Z" fill="none" stroke="${color}" stroke-width="2.2"/><path d="M35 10 Q50 20 65 10" fill="none" stroke="${color}" stroke-width="2.2"/>`,
    top: `<path d="M30 14 L12 26 L20 38 L30 30 L30 88 L70 88 L70 30 L80 38 L88 26 L70 14 Q50 24 30 14Z" fill="none" stroke="${color}" stroke-width="2.2"/>`,
    bottom: `<path d="M28 10 H72 L75 90 L55 90 L50 46 L45 90 L25 90 Z" fill="none" stroke="${color}" stroke-width="2.2"/><line x1="28" y1="10" x2="72" y2="10" stroke="${color}" stroke-width="2.2"/>`,
  };
  return `<svg viewBox="0 0 100 100" aria-hidden="true">${shapes[shape]}</svg>`;
}

/* ---------- Cart state (in-memory) ---------- */
let cart = {}; // { productId: qty }

function money(n) {
  return "₹" + n.toLocaleString("en-IN");
}

function cartTotal() {
  return Object.entries(cart).reduce((sum, [id, qty]) => {
    const p = PRODUCTS.find(p => p.id === id);
    return sum + (p ? p.price * qty : 0);
  }, 0);
}
function cartCount() {
  return Object.values(cart).reduce((a, b) => a + b, 0);
}

/* ---------- Render product grid ---------- */
const grid = document.getElementById("productGrid");

function renderGrid(filter = "all") {
  grid.innerHTML = "";
  PRODUCTS.filter(p => filter === "all" || p.category === filter).forEach(p => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <div class="product-media">
        <span class="product-tag">${p.category}</span>
        ${garmentSVG(p.shape, p.tint)}
      </div>
      <p class="product-name">${p.name}</p>
      <p class="product-category">${p.category}</p>
      <div class="product-row">
        <span class="product-price">${money(p.price)}</span>
        <button class="add-btn" data-id="${p.id}">Add to bag</button>
      </div>`;
    grid.appendChild(card);
  });
}
renderGrid();

grid.addEventListener("click", e => {
  const btn = e.target.closest(".add-btn");
  if (!btn) return;
  const id = btn.dataset.id;
  cart[id] = (cart[id] || 0) + 1;
  renderCart();
  btn.textContent = "Added ✓";
  btn.classList.add("added");
  setTimeout(() => { btn.textContent = "Add to bag"; btn.classList.remove("added"); }, 900);
});

/* ---------- Filters ---------- */
document.getElementById("filterRow").addEventListener("click", e => {
  const chip = e.target.closest(".filter-chip");
  if (!chip) return;
  document.querySelectorAll(".filter-chip").forEach(c => c.classList.remove("active"));
  chip.classList.add("active");
  renderGrid(chip.dataset.filter);
});

/* ---------- Cart drawer ---------- */
const cartDrawer = document.getElementById("cartDrawer");
const cartOverlay = document.getElementById("cartOverlay");
const cartItemsEl = document.getElementById("cartItems");
const cartFooter = document.getElementById("cartFooter");
const cartCountEl = document.getElementById("cartCount");
const cartSubtotalEl = document.getElementById("cartSubtotal");

function openCart() { cartDrawer.classList.add("open"); cartOverlay.classList.add("open"); }
function closeCart() { cartDrawer.classList.remove("open"); cartOverlay.classList.remove("open"); }

document.getElementById("cartToggle").addEventListener("click", openCart);
document.getElementById("cartClose").addEventListener("click", closeCart);
cartOverlay.addEventListener("click", () => { closeCart(); closeCheckout(); });

function renderCart() {
  cartCountEl.textContent = cartCount();
  cartSubtotalEl.textContent = money(cartTotal());

  const entries = Object.entries(cart).filter(([, qty]) => qty > 0);
  if (entries.length === 0) {
    cartItemsEl.innerHTML = `<p class="cart-empty" id="cartEmpty">Your bag is empty. Everything here starts on the <a href="#shop">shop page</a>.</p>`;
    cartFooter.style.display = "none";
    return;
  }
  cartFooter.style.display = "block";
  cartItemsEl.innerHTML = "";
  entries.forEach(([id, qty]) => {
    const p = PRODUCTS.find(p => p.id === id);
    const line = document.createElement("div");
    line.className = "cart-line";
    line.innerHTML = `
      <div class="cart-line-media">${garmentSVG(p.shape, p.tint)}</div>
      <div class="cart-line-info">
        <p class="cart-line-name">${p.name}</p>
        <p class="cart-line-meta">${p.category}</p>
        <div class="qty-control">
          <button data-action="dec" data-id="${id}" aria-label="Decrease quantity">−</button>
          <span>${qty}</span>
          <button data-action="inc" data-id="${id}" aria-label="Increase quantity">+</button>
          <button class="cart-line-remove" data-action="remove" data-id="${id}">Remove</button>
        </div>
        <p class="cart-line-price">${money(p.price * qty)}</p>
      </div>`;
    cartItemsEl.appendChild(line);
  });
}

cartItemsEl.addEventListener("click", e => {
  const btn = e.target.closest("button[data-action]");
  if (!btn) return;
  const { action, id } = btn.dataset;
  if (action === "inc") cart[id]++;
  if (action === "dec") { cart[id]--; if (cart[id] <= 0) delete cart[id]; }
  if (action === "remove") delete cart[id];
  renderCart();
  renderCheckoutSummary();
});

/* ---------- Checkout modal ---------- */
const checkoutOverlay = document.getElementById("checkoutOverlay");
const checkoutSummary = document.getElementById("checkoutSummary");
const checkoutTotalEl = document.getElementById("checkoutTotal");

function openCheckout() {
  if (cartCount() === 0) { openCart(); return; }
  renderCheckoutSummary();
  closeCart();
  checkoutOverlay.classList.add("open");
}
function closeCheckout() { checkoutOverlay.classList.remove("open"); }

document.getElementById("checkoutOpenBtn").addEventListener("click", openCheckout);
document.getElementById("checkoutClose").addEventListener("click", closeCheckout);
checkoutOverlay.addEventListener("click", e => { if (e.target === checkoutOverlay) closeCheckout(); });

function renderCheckoutSummary() {
  checkoutSummary.innerHTML = "";
  Object.entries(cart).forEach(([id, qty]) => {
    const p = PRODUCTS.find(p => p.id === id);
    if (!p) return;
    const row = document.createElement("div");
    row.className = "checkout-line";
    row.innerHTML = `<span>${p.name} × ${qty}</span><span>${money(p.price * qty)}</span>`;
    checkoutSummary.appendChild(row);
  });
  checkoutTotalEl.textContent = money(cartTotal());
}

/* ---------- Payment: Razorpay + WhatsApp fallback ----------
   IMPORTANT: swap RAZORPAY_KEY_ID for your own LIVE key before
   accepting real payments. See README.md for full instructions.
------------------------------------------------------------- */
const RAZORPAY_KEY_ID = "rzp_test_XXXXXXXXXXXX"; // <-- replace with your Razorpay key
const WHATSAPP_NUMBER = "910000000000"; // <-- replace with your business WhatsApp number (country code, no +)
const UPI_ID = "alora@okaxis"; // <-- replace with your real UPI ID (VPA) — get this from your bank's UPI app
const UPI_PAYEE_NAME = "Alora";

const checkoutForm = document.getElementById("checkoutForm");

checkoutForm.addEventListener("submit", e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(checkoutForm).entries());
  const total = cartTotal();

  if (!RAZORPAY_KEY_ID.includes("XXXX")) {
    const rzp = new Razorpay({
      key: RAZORPAY_KEY_ID,
      amount: total * 100, // paise
      currency: "INR",
      name: "Alora",
      description: `Order for ${data.name}`,
      prefill: { name: data.name, contact: data.phone },
      theme: { color: "#8B2E39" },
      handler: function () {
        alert("Payment successful! We'll confirm your order by phone shortly.");
        cart = {};
        renderCart();
        closeCheckout();
      },
    });
    rzp.open();
  } else {
    alert("Add your Razorpay key in script.js to enable card/UPI payment. Using WhatsApp checkout for now.");
    sendWhatsAppOrder(data, total);
  }
});

const upiQrWrap = document.getElementById("upiQrWrap");
const upiQrImg = document.getElementById("upiQrImg");
const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

document.getElementById("upiBtn").addEventListener("click", () => {
  if (!checkoutForm.reportValidity()) return;
  const total = cartTotal();
  const note = encodeURIComponent(`Alora order - ${cartCount()} item(s)`);
  const upiLink = `upi://pay?pa=${UPI_ID}&pn=${encodeURIComponent(UPI_PAYEE_NAME)}&am=${total}&cu=INR&tn=${note}`;

  if (isMobile) {
    // Opens the customer's UPI app (GPay/PhonePe/Paytm/etc.) directly with the amount pre-filled
    window.location.href = upiLink;
  } else {
    // Desktop has no UPI app to hand off to — show a scannable QR code instead
    upiQrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiLink)}`;
    upiQrWrap.classList.add("open");
  }
});

document.getElementById("whatsappBtn").addEventListener("click", () => {
  const data = Object.fromEntries(new FormData(checkoutForm).entries());
  if (!checkoutForm.reportValidity()) return;
  sendWhatsAppOrder(data, cartTotal());
});

function sendWhatsAppOrder(data, total) {
  const lines = Object.entries(cart).map(([id, qty]) => {
    const p = PRODUCTS.find(p => p.id === id);
    return `- ${p.name} × ${qty} (${money(p.price * qty)})`;
  });
  const message =
    `New order from Alora website%0A%0A` +
    `Name: ${data.name}%0APhone: ${data.phone}%0AAddress: ${data.address}%0A%0A` +
    `Items:%0A${lines.join("%0A")}%0A%0ATotal: ${money(total)}`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, "_blank");
}

/* ---------- Mobile nav ---------- */
const navToggle = document.getElementById("navToggle");
const mainNav = document.getElementById("mainNav");
navToggle.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", open);
});
mainNav.addEventListener("click", e => {
  if (e.target.tagName === "A") mainNav.classList.remove("open");
});

/* ---------- Misc ---------- */
document.getElementById("year").textContent = new Date().getFullYear();
renderCart();
